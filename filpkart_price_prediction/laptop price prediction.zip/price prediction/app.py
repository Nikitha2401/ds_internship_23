import os
import joblib
import numpy as np
import streamlit as st
import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

pipe  = joblib.load(r"C:\Users\Venkatesham\Desktop\internship_2023\price prediction\model.joblib")
data = joblib.load (r'c:\Users\Venkatesham\Desktop\internship_2023\price prediction\model1.joblib')




f= data[['Brand','Processor','storage','RAM','os']]
y = np.log(data['Price'])
X_train, X_test, y_train, y_test = train_test_split(f, y, test_size=0.2, random_state=47)
# onehot
# to handling the catagorical columns
step1 = ColumnTransformer(transformers=[
    ('encoder',OneHotEncoder(handle_unknown='ignore',sparse=False,drop='first'),[0,1,2,3,4])
],remainder='passthrough')

step2 = RandomForestRegressor(n_estimators=100,
                              random_state=3,
                              max_samples=0.5,
                              max_features=0.75,
                              max_depth=15)
pipe = Pipeline([
    ('step1',step1),
    ('step2',step2)
])
pipe.fit(X_train,y_train)

# input section
st.title("Laptop Price Predictor")
#Now we will take user input one by one as per our dataframe
#Brand
#company = st.selectbox('Brand', df['Company'].unique())
Brand = st.selectbox('Brand', data['Brand'].unique())
# processor
processor = st.selectbox("Processor",data["Processor"].unique())
# storage
storage = st.selectbox('Storage',data['storage'].unique())
#ram
ram = st.selectbox("Ram", [2,4,6,8,12,16,24,32,64])
# screensize
os = st.selectbox('os',data['os'].unique())
    
butt = st.button("Predict ")
if butt:
        st.balloons()
        query = np.array([Brand, processor,storage,ram,os])
        query = query.reshape(1, -1)
        p = pipe.predict(query)[0]
        result = np.exp(p)
        st.subheader(" Predicted Price is: ")
        st.subheader(":red[₹{}]".format(result.round(2)))

